export const films = [
    {
      id: 1,
      name: 'Harry Potter',
      year: 2000,
      image: 'https://static.posters.cz/image/1300/%D0%9F%D0%BB%D0%B0%D0%BA%D0%B0%D1%82%D0%B8/harry-potter-philosopher-s-stone-i104639.jpg',
      director: 'Bob Smith',
      description: 'Lorem ipsum, dolor sit amet consectetur adipisicing elit. Vero, mollitia qui. Sint, numquam velit dolores quo est ratione libero eius, vero et nisi nostrum ullam? Dolorum expedita fuga aliquam quia!'
    },
    {
      id: 2,
      name: 'La la land',
      year: 2011,
      image: 'https://upload.wikimedia.org/wikipedia/ru/e/e4/La_La_Land.jpg',
      director: 'Mary GrandPré',
      description: 'Lorem ipsum, dolor sit amet consectetur adipisicing elit. Vero, mollitia qui. Sint, numquam velit dolores quo est ratione libero eius, vero et nisi nostrum ullam? Dolorum expedita fuga aliquam quia!'
    },
    {
      id: 3,
      name: 'Green mile',
      year: 2015,
      image: 'https://m.media-amazon.com/images/M/MV5BYjAxOWIzZmUtYzNiZi00OTUyLWE1YjgtMzI5ZTNkNmU5N2IxXkEyXkFqcGdeQXVyNjAwNDUxODI@._V1_.jpg',
      director: 'David Barron',
      description: 'Lorem ipsum, dolor sit amet consectetur adipisicing elit. Vero, mollitia qui. Sint, numquam velit dolores quo est ratione libero eius, vero et nisi nostrum ullam? Dolorum expedita fuga aliquam quia!'
    },
    {
      id: 4,
      name: 'Kill bill',
      year: 2001,
      image: 'https://images-na.ssl-images-amazon.com/images/S/pv-target-images/ca4af7fb6e19a86e6ecffa246f9cb22af11e39cedc9236a468bc8f043676df96._RI_V_TTW_.jpg',
      director: 'David Heyman',
      description: 'Lorem ipsum, dolor sit amet consectetur adipisicing elit. Vero, mollitia qui. Sint, numquam velit dolores quo est ratione libero eius, vero et nisi nostrum ullam? Dolorum expedita fuga aliquam quia!'
    },
    {
      id: 5,
      name: 'Resident Evil',
      year: 2005,
      image: 'https://m.media-amazon.com/images/M/MV5BYmY0NjcwMWMtN2MyNC00ZmZjLWEwZTAtM2ExYWE1NDUwNWQyXkEyXkFqcGdeQXVyODE5NzE3OTE@._V1_FMjpg_UX1000_.jpg',
      director: 'J. K. Rowling',
      description: 'Lorem ipsum, dolor sit amet consectetur adipisicing elit. Vero, mollitia qui. Sint, numquam velit dolores quo est ratione libero eius, vero et nisi nostrum ullam? Dolorum expedita fuga aliquam quia!'
    },
  ];
  
  
  export default films;