import React from 'react';
import FilmFilter from './FilmFilter';
import FilmBlock from './FilmBlock';
import './style.css'
import films from './films';
const Films = () => {
    return (
        <div>
            <h2>Films</h2>
            <FilmFilter />
            <div className='film-field'>
                {films.map((film) =>(
                <FilmBlock name={film.name} poster={film.image} year={film.year} key={film.id}/>
                ))}
            </div>
        </div>
    );
}

export default Films;
