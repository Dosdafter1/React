import React from 'react';
import './style.css'
const FilmBlock = ({name,poster,year}) => {
    return (
        <div className='film-block'>
            <img src={poster} alt="" />
            <p>{name}</p>
            <p>{year}</p>
        </div>
    );
}

export default FilmBlock;
