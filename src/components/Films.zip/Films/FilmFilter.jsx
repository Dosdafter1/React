import React from 'react';

const FilmFilter = () => {
    return (
        <div>
            <form action="">
                <input type="text" placeholder='Name...'/>
                <button>Search</button>
            </form>
        </div>
    );
}

export default FilmFilter;
